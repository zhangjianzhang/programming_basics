

__version__ = '0.42.1'
__license__ = 'MIT'


from . import getidinfo
from . import verifyid
from . import areas
