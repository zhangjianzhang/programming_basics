# !/usr/bin/env python
# -*- coding: utf-8 -*-

"""
@project: softwareAdviceSpider
@file   : __init__.py.py
@version: 1.0
@time   : 2018-03-15
@author : Jianzhang Zhang, <jianzhang.zhang@foxmail.com>
"""